<?php
/**
 * ThessNest — Page Template
 *
 * Renders standard WordPress pages.
 *
 * @package ThessNest
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

<main id="main-content" role="main">
	<div class="container" style="padding:var(--space-12) var(--space-4);">

		<?php
		while ( have_posts() ) :
			the_post();
			?>
			<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
				<h1 style="font-size:var(--font-size-3xl);margin-bottom:var(--space-6);color:var(--color-primary);">
					<?php the_title(); ?>
				</h1>

				<div class="entry-content" style="line-height:1.8;color:var(--color-text);">
					<?php the_content(); ?>
				</div>
			</article>
			<?php
		endwhile;
		?>

	</div>
</main>

<?php get_footer(); ?>
