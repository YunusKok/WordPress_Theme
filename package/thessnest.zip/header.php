<?php
/**
 * ThessNest — Header Template
 *
 * Renders the site header: Logo, primary navigation, and action buttons.
 * Includes a mobile off-canvas drawer for smaller viewports.
 *
 * @package ThessNest
 */

defined( 'ABSPATH' ) || exit;
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="theme-color" content="#1B2A4A">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php
if ( function_exists( 'wp_body_open' ) ) {
	wp_body_open();
}
?>

<!-- ===== SITE HEADER ===== -->
<header class="site-header" id="site-header" role="banner">
	<div class="header-inner">

		<!-- Logo -->
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="site-logo" aria-label="<?php esc_attr_e( 'ThessNest Home', 'thessnest' ); ?>">
			<!-- Inline SVG icon – house + location pin -->
			<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
				<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
				<polyline points="9 22 9 12 15 12 15 22"/>
			</svg>
			<span>Thess<span class="logo-accent">Nest</span></span>
		</a>

		<!-- Primary Navigation (Desktop) -->
		<nav class="primary-nav" role="navigation" aria-label="<?php esc_attr_e( 'Primary Navigation', 'thessnest' ); ?>">
			<?php
			wp_nav_menu( array(
				'theme_location' => 'primary',
				'container'      => false,
				'items_wrap'     => '%3$s',
				'depth'          => 1,
				'fallback_cb'    => 'thessnest_fallback_menu',
			) );
			?>
		</nav>

		<!-- Header Actions -->
		<div class="header-actions">

			<!-- Add Listing Button (outline) -->
			<a href="#" class="btn btn-outline btn-add-listing">
				<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
					<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
				</svg>
				<span class="btn-text"><?php esc_html_e( 'Add Listing', 'thessnest' ); ?></span>
			</a>

			<!-- Sign In -->
			<a href="#" class="btn-signin">
				<?php esc_html_e( 'Sign In', 'thessnest' ); ?>
			</a>

			<!-- Mobile Menu Toggle -->
			<button class="mobile-menu-toggle" id="mobile-menu-toggle" aria-label="<?php esc_attr_e( 'Toggle Menu', 'thessnest' ); ?>" aria-expanded="false" aria-controls="mobile-nav-drawer">
				<span class="hamburger-icon">
					<span></span>
					<span></span>
					<span></span>
				</span>
			</button>
		</div>
	</div>
</header>

<!-- ===== MOBILE NAV DRAWER ===== -->
<div class="mobile-nav-overlay" id="mobile-nav-overlay" aria-hidden="true"></div>
<aside class="mobile-nav-drawer" id="mobile-nav-drawer" role="dialog" aria-modal="true" aria-label="<?php esc_attr_e( 'Mobile Navigation', 'thessnest' ); ?>">
	<button class="mobile-nav-close" id="mobile-nav-close" aria-label="<?php esc_attr_e( 'Close Menu', 'thessnest' ); ?>">
		<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
			<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
		</svg>
	</button>

	<?php
	wp_nav_menu( array(
		'theme_location' => 'primary',
		'container'      => false,
		'depth'          => 1,
		'fallback_cb'    => 'thessnest_fallback_menu_mobile',
	) );
	?>

	<div class="mobile-nav-actions">
		<a href="#" class="btn btn-outline"><?php esc_html_e( 'Add Listing', 'thessnest' ); ?></a>
		<a href="#" class="btn btn-primary"><?php esc_html_e( 'Sign In', 'thessnest' ); ?></a>
	</div>
</aside>
